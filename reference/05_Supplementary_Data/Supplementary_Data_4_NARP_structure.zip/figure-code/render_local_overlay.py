"""Authors: Jinlong Ru, Cunli Pan. Saved-coordinate local overlay; no prediction.
Run from project root in the already-installed Science structbio environment.
"""
import os, json, hashlib
from pathlib import Path
os.environ['PYOPENGL_PLATFORM'] = 'osmesa'
import pymol
pymol.pymol_argv = ['pymol', '-cq']
pymol.finish_launching()
from pymol import cmd

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
SRC = ROOT/'candidates/structure-v2026.10.15.1/continuation-2026-10-16'
model = SRC/'compare/orf102_full_gemmi.cif'
ref = SRC/'compare/1MK0.cif'
assert model.is_file() and ref.is_file()
cmd.load(str(model), 'full')
cmd.create('orf102_GIY', 'full and chain A and resi 3-87')
cmd.delete('full')
cmd.load(str(ref), 'I_TevI')
cmd.remove('not polymer.protein')
assert cmd.count_atoms('orf102_GIY and name CA') == 85
assert cmd.count_atoms('I_TevI and name CA') == 97
assert cmd.count_atoms('all') > 0
before = cmd.get_object_matrix('I_TevI')
result = cmd.cealign('orf102_GIY', 'I_TevI', object='CE_pairs')
pairs = cmd.get_raw_alignment('CE_pairs')
lookup = {}
for obj in ['orf102_GIY', 'I_TevI']:
    lookup[obj] = {a.index:a for a in cmd.get_model(obj).atom}
rows = []
for pair in pairs:
    assert len(pair) == 2
    atoms = {obj:lookup[obj][idx] for obj,idx in pair}
    a,b = atoms['orf102_GIY'],atoms['I_TevI']
    assert a.name == b.name == 'CA'
    rows.append({'orf102_chain':a.chain,'orf102_residue':int(a.resi),
                 'orf102_resname':a.resn,'reference_chain':b.chain,
                 'reference_residue':int(b.resi),'reference_resname':b.resn,
                 'orf102_CA':list(a.coord),'reference_transformed_CA':list(b.coord)})
assert len(rows) == result['alignment_length'] == 80
import numpy as np
rmsd = float(np.sqrt(np.mean([np.sum((np.array(r['orf102_CA'])-r['reference_transformed_CA'])**2) for r in rows])))
assert abs(rmsd-result['RMSD']) < .001
cmd.hide('everything')
cmd.show('cartoon', 'orf102_GIY or I_TevI')
cmd.color('0x6D9F99','orf102_GIY')
cmd.color('0x3F3F3F','I_TevI')
cmd.bg_color('white')
cmd.set('ray_opaque_background',1)
cmd.set('ray_shadows',0)
cmd.set('antialias',2)
cmd.set('orthoscopic',1)
cmd.set('specular',.1)
cmd.orient('orf102_GIY')
cmd.zoom('orf102_GIY or I_TevI',2)
cmd.disable('CE_pairs')
cmd.png(str(OUT/'figures/ORF102-GIY-local-overlay.png'),width=1600,height=1200,dpi=600,ray=1)
cmd.save(str(OUT/'figures/ORF102-GIY-local-overlay.pse'))
cmd.save(str(OUT/'data/1MK0-transformed.cif'),'I_TevI')
import csv
with (OUT/'data/ORF102-1MK0-CE-pairs.tsv').open('w') as f:
    keys=['orf102_chain','orf102_residue','orf102_resname','reference_chain','reference_residue','reference_resname']
    w=csv.DictWriter(f,fieldnames=keys,delimiter='\t');w.writeheader()
    w.writerows({k:r[k] for k in keys} for r in rows)
report={'algorithm':'PyMOL cealign','pymol_version':cmd.get_version(),
        'target':'ORF102 sample 1, chain A, residues 3-87',
        'mobile':'experimental I-TevI 1MK0 chain A',
        'defaults':{'window':8,'gap_max':30,'d0':3.0,'d1':4.0},
        'result':result,'n_CA_pairs':len(rows),'independent_coordinate_RMSD_angstrom':rmsd,
        'transform_before':before,'transform_after':cmd.get_object_matrix('I_TevI'),
        'view':list(cmd.get_view()),'pairs_with_transformed_coordinates':rows,
        'input_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [model,ref]},
        'scope':'New saved-coordinate structural alignment and rendering only; no protein prediction, Pfam rescan or statistical test.'}
(OUT/'data/ORF102-1MK0-CE.json').write_text(json.dumps(report,indent=2)+'\n')
print('CE pairs',len(rows),'RMSD',rmsd,flush=True)
cmd.quit()
