"""Authors: Jinlong Ru, Cunli Pan. Reproducible v35 S2 editorial figure.
Reads saved analytical inputs and structures; no model fitting or prediction.
Run from project root: python3 outputs/s2-narp-v35-2026-10-16/build_s2.py
"""
from pathlib import Path
import csv, json, hashlib, math, shutil, sqlite3, io
import fitz, numpy as np, yaml
from PIL import Image, ImageChops

ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent; FIG=OUT/'figures'; DATA=OUT/'data'
BASE=ROOT/'deliveries/2026-10-15-v30-literature-integration_analysis-v2026.09.28.1_run-20261015T223634-85878/bundle/review-candidate'
TRIAL=ROOT/'candidates/claude-science-figure-trials-2026-10-16'
STRUCT=ROOT/'candidates/structure-v2026.10.15.1/continuation-2026-10-16'
MM=72/25.4
style=yaml.safe_load((ROOT/'config/style.yml').read_text())
pal=yaml.safe_load((ROOT/'config/palettes.yml').read_text())
reg=Path('/System/Library/Fonts/Supplemental/Arial.ttf'); bold=reg.with_name('Arial Bold.ttf')
assert reg.is_file() and bold.is_file()
fonts={'AR':fitz.Font(fontfile=str(reg)),'AB':fitz.Font(fontfile=str(bold))}
ramps=json.loads((DATA/'colour-ramps.json').read_text())
rgb=lambda h:tuple(int(h[i:i+2],16)/255 for i in (1,3,5))
INK=rgb(style['colours']['ink_dark']); LIGHT=rgb(style['colours']['grey_light'])
TEAL=rgb(pal['he']['fill']); PURPLE=rgb(pal['gene']['narp_member'])
checks=[]; text_boxes=[]
def ck(name,ok):
    checks.append({'check':name,'pass':bool(ok)})
    assert ok,name
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rd(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def font_page(p):
    p.insert_font(fontname='AR',fontfile=str(reg));p.insert_font(fontname='AB',fontfile=str(bold))
def txt(p,x,y,s,size=8,b=False,align='left',col=INK,rot=0):
    key='AB' if b else 'AR';w=fonts[key].text_length(s,fontsize=size)/MM
    if align=='center':x-=w/2
    if align=='right':x-=w
    p.insert_text((x*MM,y*MM),s,fontsize=size,fontname=key,color=col,rotate=rot)
def ln(p,x1,y1,x2,y2,col=LIGHT,width=.12,dashes=None):
    p.draw_line((x1*MM,y1*MM),(x2*MM,y2*MM),color=col,width=width*MM,dashes=dashes)
def rect(p,x,y,w,h,fill=None,col=LIGHT,width=.12):
    p.draw_rect(fitz.Rect(x*MM,y*MM,(x+w)*MM,(y+h)*MM),fill=fill,color=col,width=width*MM)
def arrow(p,x1,x2,y,strand,fill,col=LIGHT,width=.12):
    h=1.4;head=min(2.4,(x2-x1)*.4)
    pts=[(x1,y-h),(x2-head,y-h),(x2,y),(x2-head,y+h),(x1,y+h)] if strand==1 else [(x2,y-h),(x1+head,y-h),(x1,y),(x1+head,y+h),(x2,y+h)]
    pts=[fitz.Point(x*MM,yy*MM) for x,yy in pts]
    shape=p.new_shape();shape.draw_polyline(pts+[pts[0]]);shape.finish(color=col,fill=fill,width=width*MM,closePath=True);shape.commit()
def image_crop(path,out):
    im=Image.open(path).convert('RGB');mask=ImageChops.difference(im,Image.new('RGB',im.size,'white')).convert('L').point(lambda v:255 if v>12 else 0)
    b=mask.getbbox();b=(max(0,b[0]-8),max(0,b[1]-8),min(im.width,b[2]+8),min(im.height,b[3]+8))
    im.crop(b).save(out);return out
def unicode_map(doc):
    seen=set()
    for page in doc:
        for f in page.get_fonts(full=True):
            if f[4] not in fonts or f[0] in seen:continue
            seen.add(f[0]); pairs=[]
            for c in [*map(chr,range(32,127)),'Å','–','−']:
                gid=fonts[f[4]].has_glyph(ord(c))
                if gid:pairs.append(f'<{gid:04X}> <{ord(c):04X}>')
            cmap='/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /ExplicitArial def\n/CMapType 2 def\n1 begincodespacerange\n<0000> <FFFF>\nendcodespacerange\n'+str(len(pairs))+' beginbfchar\n'+'\n'.join(pairs)+'\nendbfchar\nendcmap\nCMapName currentdict /CMap defineresource pop\nend\nend'
            x=doc.get_new_xref();doc.update_object(x,'<<>>');doc.update_stream(x,cmap.encode());doc.xref_set_key(f[0],'ToUnicode',f'{x} 0 R')

inputs=[ROOT/'analyses/data/030-function-inputs/narp_definitions.tsv',ROOT/'analyses/data/030-function-inputs/narp_carrier_sample_abundance.tsv',
        TRIAL/'A-neighbourhood/narp2-neighbourhood-source.tsv',BASE/'FigureS2-plot-values.tsv',
        STRUCT/'models/orf102_seed0x5_sample1.cif',STRUCT/'models/plddt_orf102_seed0x5_sample1.txt',STRUCT/'models/pae_orf102_seed0x5_sample1.npy',
        STRUCT/'figures/panel_confidence.png',DATA/'ORF102-1MK0-CE.json',ROOT/'config/style.yml',ROOT/'config/palettes.yml',
        ROOT/'analyses/data/00-raw/d012-tse-construction/p0061_snapshot.sqlite']
dump(OUT/'input-manifest.json',{str(p.relative_to(ROOT)):sha(p) for p in inputs})
narp=rd(inputs[0]);abund=rd(inputs[1]);genes=rd(inputs[2]);old=rd(BASE/'FigureS2-plot-values.tsv')
top=['vOTU0052','vOTU0113','vOTU0131','vOTU0544','vOTU1643']
ck('five DF NARP2 identities',set(top)=={r['vOTU_id'] for r in narp if r['df_narp2']=='1'})
ordered=top+[r['vOTU_id'] for r in narp if r['vOTU_id'] not in top]
rowmap={r['vOTU_id']:r for r in narp}; samples=['bc1','bd1','bc2','gc1','gd1','oc1','od1']
heatids=top+['vOTU0863','vOTU1898'];heat={(r['vOTU_id'],r['sample_id']):r for r in abund}
ck('49 unique abundance cells',len(heat)==len(abund)==49)
ck('8 detected cells',sum(float(r['catalogue_percent'])>0 for r in abund)==8)
for r in abund:
    ck('abundance / TPM '+r['vOTU_id']+' '+r['sample_id'],abs(float(r['catalogue_percent'])-float(r['trimmed_tpm_masked'])/10000)<1e-12)
    v=next(x for x in old if x['panel']=='C' and x['item']==r['vOTU_id']+' '+r['sample_id'])
    ck('old abundance unchanged '+r['vOTU_id']+' '+r['sample_id'],abs(float(v['value'])-float(r['catalogue_percent']))<1e-12)
conn=sqlite3.connect('file:'+str(ROOT/'analyses/data/00-raw/d012-tse-construction/p0061_snapshot.sqlite')+'?mode=ro',uri=True);conn.row_factory=sqlite3.Row
adstart=conn.execute('select start_position from virus_gene_annotation_dramv where vOTU_id=? and gene_position=166',('vOTU0052',)).fetchone()[0]
adend=conn.execute('select end_position from virus_gene_annotation_dramv where vOTU_id=? and gene_position=103',('vOTU0052',)).fetchone()[0]
dump(DATA/'atd1-distance.json',{'source':'analyses/data/00-raw/d012-tse-construction/p0061_snapshot.sqlite','table':'virus_gene_annotation_dramv',
     'vOTU':'vOTU0052','atd1_ORF':166,'atd1_start_bp':adstart,'NARP_ORF103_end_bp':adend,
     'coordinate_difference_bp':adstart-adend,'rounded_kb':round((adstart-adend)/1000),
     'derivation':'ATD1 start minus terminal NARP2-member end; rounded kb, source coordinates 1-based'})
fields=['vOTU_id','vcontig_id','protein_id','gene_position','start_position','end_position','strandedness','ko_id','kegg_hit','pfam_hits','vogdb_hits','vogdb_categories','peptidase_family']
norm=lambda x:'' if x is None or str(x)=='NA' else str(x)
for g in genes:
    z=conn.execute('select * from virus_gene_annotation_dramv where vOTU_id=? and protein_id=?',(g['vOTU_id'],g['protein_id'])).fetchall()
    ck('unique database ORF '+g['protein_id'],len(z)==1)
    ck('original fields '+g['protein_id'],all(norm(g[k])==norm(z[0][k]) for k in fields))
ck('34 ORFs',len(genes)==34)
shutil.copy2(inputs[2],DATA/'narp2-neighbourhood-source.tsv')
shutil.copy2(inputs[1],DATA/'narp_carrier_sample_abundance.tsv')
pl=np.loadtxt(STRUCT/'models/plddt_orf102_seed0x5_sample1.txt');pae=np.load(STRUCT/'models/pae_orf102_seed0x5_sample1.npy')
cross=float(np.concatenate([pae[2:87,152:184].ravel(),pae[152:184,2:87].ravel()]).mean())
ce=json.loads((DATA/'ORF102-1MK0-CE.json').read_text())
ck('local overlay 80 actual CA pairs',ce['n_CA_pairs']==80)
ck('coordinate RMSD independently recomputed',abs(ce['independent_coordinate_RMSD_angstrom']-ce['result']['RMSD'])<.001)
ck('PAE 24.7',round(cross,1)==24.7)

doc=fitz.open();p=doc.new_page(width=180*MM,height=245*MM);font_page(p)
txt(p,3,7,'a',11,True);txt(p,98,7,'b',11,True)
# A: 19 x four original membership flags, original row order retained.
xcols=[31,39,47,55]; keys=['df_narp1','df_narp2','ko_K03462_K13522','dbapis_narp_targeting']
heads=['NARP1 (3)','NARP2 (5)','KO pair (6)','dbAPIS (19)']
cols=[PURPLE,PURPLE,rgb(pal['function_calls']['ko_rule']),rgb(pal['function_calls']['anti_defense_tool'])]
oldflags={r['item']:float(r['value']) for r in old if r['panel']=='B'}
oldnames=['NARP1','NARP2','KO rule','dbAPIS']
for r in narp:
    for k,name in zip(keys,oldnames):
        ck('unchanged definition '+r['vOTU_id']+' '+name,oldflags[r['vOTU_id']+' '+name]==int(r[k]))
for x,s in zip(xcols,heads):txt(p,x+1.5,26,s,rot=90)
txt(p,66,17,'CheckV',b=True);txt(p,66,21,'class / %',b=True)
for j,vid in enumerate(ordered):
    y=29+j*3.5;r=rowmap[vid];txt(p,27,y+2.25,vid,align='right')
    for x,k,c in zip(xcols,keys,cols):rect(p,x,y,6.8,2.95,fill=c if r[k]=='1' else (1,1,1))
    short={'Medium-quality':'MQ','Low-quality':'LQ','High-quality':'HQ','Complete':'C'}[r['checkv_quality']]
    txt(p,66,y+2.25,short+' '+f"{float(r['checkv_completeness_pct']):.1f}%")
    if vid=='vOTU0052':rect(p,29.8,y-.3,33.2,3.55,col=INK,width=.4)
    if j==4:ln(p,29, y+4,90,y+4,col=INK,dashes='[2 2]')
txt(p,31,100,'MQ / LQ / HQ: recovery classes')
# B: same 49 values, full-catalogue denominator, same log colour scale.
x0=120;cw=7.4
for j,s in enumerate(samples):txt(p,x0+j*cw+cw/2,27,s,align='center')
for i,vid in enumerate(heatids):
    y=30+i*6.6+(2 if i>=5 else 0);txt(p,118,y+4.0,vid,align='right')
    for j,s in enumerate(samples):
        v=float(heat[(vid,s)]['catalogue_percent']);col=(1,1,1)
        if v>0:col=rgb(ramps['heat'][int(np.clip((math.log10(v)-math.log10(.02))/(math.log10(4)-math.log10(.02))*255,0,255))])
        rect(p,x0+j*cw,y,cw-.6,5.5,fill=col)
        txt(p,x0+j*cw+(cw-.6)/2,y+3.7,format(v,'.2g') if v else '–',align='center',col=(1,1,1) if v>=1 else INK)
    if i==4:ln(p,101,y+6.5,172,y+6.5,dashes='[2 2]')
for k in range(128):rect(p,124+k/128*44,84,44/128+.01,2,fill=rgb(ramps['heat'][round(k/127*255)]),col=None)
for v in [.03,.1,.3,1,3]:
    x=124+(math.log10(v)-math.log10(.02))/(math.log10(4)-math.log10(.02))*44
    txt(p,x,90,str(v),align='center')
txt(p,146,96,'% of masked catalogue',align='center')

# C: real-coordinate neighborhoods. Equal bp scaling; reverse complement two rows.
txt(p,3,109,'c',11,True)
rect(p,33,104.7,3,2,fill=PURPLE,col=PURPLE);txt(p,38,107,'NARP2 member')
rect(p,74,104.7,3,2,fill=(1,1,1),col=TEAL,width=.4);txt(p,79,107,'Nuclease-related candidate')
rect(p,142,104.7,3,2,fill=LIGHT,col=LIGHT);txt(p,147,107,'Other ORF')
xp=lambda x:33+(x+1700)/7100*141
between=[]
for i,vid in enumerate(top):
    y=116+i*10.6;gg=[g for g in genes if g['vOTU_id']==vid];nm=next(g for g in gg if g['ko_id']=='K13522')
    neg=nm['strandedness']=='-1';anchor=int(nm['end_position'] if neg else nm['start_position'])
    txt(p,5,y,vid);txt(p,5,y+3.5,'MQ' if i==0 else 'LQ',col=rgb(style['colours']['grey_dark']))
    intervals=[]
    for g in gg:
        lo,hi=int(g['start_position']),int(g['end_position']);a,b=(anchor-hi,anchor-lo) if neg else (lo-anchor,hi-anchor)
        intervals.append((a,b,g))
    ln(p,xp(min(a for a,b,g in intervals)),y,xp(max(b for a,b,g in intervals)),y)
    for a,b,g in intervals:
        nuc=g['endonuclease_annotation_in_db']=='True' or (vid=='vOTU0052' and g['gene_position']=='102')
        member=g['ko_id'] in ['K13522','K03462'];fill=PURPLE if member else ((1,1,1) if nuc else LIGHT)
        direction=int(g['strandedness'])*(-1 if neg else 1)
        arrow(p,xp(a),xp(b),y,direction,fill,TEAL if nuc else (PURPLE if member else LIGHT),.4 if nuc else .12)
        if member:
            txt(p,(xp(a)+xp(b))/2,y+.95,'NMNAT' if g['ko_id']=='K13522' else 'NAMPT',align='center',col=(1,1,1))
        if nuc:
            lab='ORF'+g['gene_position'];cx=(xp(a)+xp(b))/2
            ln(p,cx,y-1.7,cx,y-3.1,col=TEAL);txt(p,cx,y-3.8,lab,align='center')
    aa=[int(g['gene_position']) for g in gg if g['ko_id'] in ['K13522','K03462']]
    between.append({'vOTU_id':vid,'intervening_ORFs':max(aa)-min(aa)-1})
    if vid=='vOTU1643':
        boundary=xp(anchor-1);ln(p,boundary,y-2.8,boundary,y+2.8,col=INK,width=.45);txt(p,boundary+2,y+3,'contig end')
for t in [-1000,0,1000,2000,3000,4000,5000]:
    ln(p,xp(t),164,xp(t),165,col=INK);txt(p,xp(t),169,str(t),align='center')
txt(p,104,174,'Position relative to NMNAT start (bp; shared scale)',align='center')
ck('intervening counts unchanged',[r['intervening_ORFs'] for r in between]==[1,1,4,0,0])
with (DATA/'local-NARP2-spacing.tsv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=['vOTU_id','intervening_ORFs'],delimiter='\t');w.writeheader();w.writerows(between)

# D: full-length confidence render plus single, traceable catalytic-domain overlay.
txt(p,3,181,'d',11,True)
txt(p,31,182,'ORF102',b=True)
xdom=lambda n:57+(n-1)/210*115
ln(p,57,185,172,185)
for lo,hi,lab in [(3,87,'GIY-YIG (3–87)'),(153,184,'NUMOD-like (153–184)')]:
    rect(p,xdom(lo),184, xdom(hi)-xdom(lo),2,fill=TEAL,col=TEAL)
    txt(p,(xdom(lo)+xdom(hi))/2,181,lab,align='center')
for n in [1,100,211]:txt(p,xdom(n),190,str(n),align='center')
full=image_crop(STRUCT/'figures/panel_confidence.png',FIG/'ORF102-full-trim.png')
overlay=image_crop(FIG/'ORF102-GIY-local-overlay.png',FIG/'ORF102-overlay-trim.png')
txt(p,44,195,'Full-length prediction (211 aa)',align='center')
txt(p,137,195,'GIY-YIG reference comparison',align='center')
p.insert_image(fitz.Rect(7*MM,197*MM,83*MM,233*MM),filename=str(full),keep_proportion=True)
p.insert_image(fitz.Rect(99*MM,197*MM,176*MM,232*MM),filename=str(overlay),keep_proportion=True)
for k in range(100):rect(p,6+k/100*25,235,25/100+.01,1.7,fill=rgb(ramps['viridis'][round(k/99*255)]),col=None)
txt(p,6,241,'0.5');txt(p,30,241,'1.0',align='right');txt(p,35,238,'pLDDT')
ln(p,100,235.8,104,235.8,col=TEAL,width=.7);txt(p,106,237,'ORF102, 3–87')
ln(p,139,235.8,143,235.8,col=(.247,.247,.247),width=.7);txt(p,145,237,'I-TevI (1MK0)')
txt(p,69,243,'Domain arrangement uncertain; cross-region PAE 24.7 Å')

unicode_map(doc);doc.save(FIG/'FigureS2.pdf',garbage=4,deflate=True)
p.get_pixmap(dpi=300,alpha=False).save(FIG/'FigureS2.png');(FIG/'FigureS2.svg').write_text(p.get_svg_image(text_as_path=False))
spans=[s for b in p.get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l['spans'] if s['text'].strip()]
ck('minimum font 8 pt',min(s['size'] for s in spans)>=7.99)
for s in spans:ck('text in page '+s['text'],p.rect.contains(fitz.Rect(s['bbox'])))
ck('four panel labels',all(t in p.get_text().split() for t in ['a','b','c','d']))

# Display values use new panel identities, with source-preserving records.
vals=[]
for r in old:
    if r['panel'] in ['B','C','D']:
        vals.append(dict(r,panel={'B':'A','C':'B','D':'D'}[r['panel']]))
for g in genes:
    for k in ['start_position','end_position']:
        vals.append({'panel':'C','item':g['protein_id']+' '+k,'value':g[k],'unit':'original contig bp; original strand retained in source table'})
for r in between:vals.append({'panel':'C','item':r['vOTU_id']+' intervening ORFs','value':r['intervening_ORFs'],'unit':'annotated ORFs between anchors'})
for key,v,unit in [('mean pLDDT',float(pl.mean()),'native 0–1'),('cross-region PAE',cross,'angstrom'),('CE pairs',80,'paired CA'),('CE RMSD',ce['independent_coordinate_RMSD_angstrom'],'angstrom')]:
    vals.append({'panel':'D','item':key,'value':v,'unit':unit})
with (FIG/'FigureS2-plot-values.tsv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=['panel','item','value','unit'],delimiter='\t');w.writeheader();w.writerows(vals)
dump(FIG/'FigureS2-export.json',{'writing_version':'v2026.09.28.35','base_scientific_run':'20261015T223634-85878','new_full_analysis_run':False,'page_mm':[180,245],'qa':checks,'structure_rendering':'embedded raster within vector labels; not an all-vector molecular rendering'})
dump(OUT/'checks.json',{'checks':checks,'n_checks':len(checks),'all_pass':all(c['pass'] for c in checks),'original_A_moved_to':'Data 1 S22 and Note 1 Table C','new_panel_mapping':{'A':'old B','B':'old C','C':'five saved NARP2 neighborhoods','D':'ORF102 domain track and saved structure plus local overlay'}})

# Physically equal-width comparison; older figure is not stretched vertically.
cmp=fitz.open()
for f,label in [(BASE/'FigureS2.pdf','v34: 180 x 195 mm'),(FIG/'FigureS2.pdf','v35: 180 x 245 mm')]:
    s=fitz.open(f);cp=cmp.new_page(width=180*MM,height=258*MM);font_page(cp);txt(cp,4,7,label)
    cp.show_pdf_page(fitz.Rect(0,12*MM,180*MM,(12+s[0].rect.height/MM)*MM),s,0)
unicode_map(cmp);cmp.save(FIG/'FigureS2-v34-v35-comparison.pdf',garbage=4,deflate=True)
print('S2 built:',len(checks),'checks; 180 x 245 mm; no analytical model or prediction rerun.')
