
import json, numpy as np
from pymol import cmd
import matplotlib
MODEL   = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/compare/orf102_full_gemmi.cif"
PLDDT   = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/models/plddt_orf102_seed0x5_sample1.txt"
CAT_REF = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/compare/1MK0.cif"
UVRC    = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/compare/1YD0.cif"
DNA_REF = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/compare/1T2T.cif"
OUT     = "/Users/pan/Documents/Codex/RecWaterVirome/candidates/structure-v2026.10.15.1/continuation-2026-10-16/figures"

cmd.set("ray_opaque_background", 1); cmd.bg_color("white")
cmd.set("cartoon_transparency", 0); cmd.set("ray_shadows", 0)
cmd.set("antialias", 2); cmd.set("orthoscopic", 1); cmd.set("specular", 0.15)
cmd.set("cartoon_fancy_helices", 1)

cmd.load(MODEL, "orf102")
cmd.hide("everything"); cmd.show("cartoon", "orf102")
cmd.orient("orf102")
VIEW = cmd.get_view()          # one view reused by panels A and B
report = {"view": list(VIEW)}

# ---- panel A: coloured by predicted confidence (native pLDDT 0-1, viridis) ----
pl = np.loadtxt(PLDDT)
cmap = matplotlib.colormaps["viridis"]
lo, hi = 0.5, 1.0               # ramp bounds stated in the legend
for i, v in enumerate(pl, start=1):
    r_, g_, b_ = cmap((min(max(v, lo), hi) - lo) / (hi - lo))[:3]
    cmd.set_color(f"c{i}", [float(r_), float(g_), float(b_)])
    cmd.color(f"c{i}", f"orf102 and resi {i}")
cmd.set_view(VIEW)
cmd.png(f"{OUT}/panel_confidence.png", width=1800, height=1500, dpi=600, ray=1)
report["plddt_ramp"] = [lo, hi]

# ---- panel B: coloured by the existing sequence-annotation domains ----
DOM = {"catalytic": ("3-87", "0xCC79A7"), "inter": ("88-152", "0xBDBDBD"),
       "numod": ("153-184", "0x4D4D4D"), "nflank": ("1-2", "0xBDBDBD"),
       "cflank": ("185-211", "0xBDBDBD")}
for name, (resi, col) in DOM.items():
    cmd.color(col, f"orf102 and resi {resi}")
cmd.set_view(VIEW)
cmd.png(f"{OUT}/panel_domains.png", width=1800, height=1500, dpi=600, ray=1)

# ---- panel C: superposition of the catalytic domain on two references ----
cmd.delete("all")
cmd.load(MODEL, "orf102"); cmd.create("cat", "orf102 and resi 3-87"); cmd.delete("orf102")
cmd.load(CAT_REF, "itevi"); cmd.load(UVRC, "uvrc")
cmd.remove("not polymer.protein")
ali = {}
for mob, name in [("itevi", "I-TevI_1MK0"), ("uvrc", "UvrC_1YD0")]:
    try:
        res = cmd.cealign("cat", mob)
        ali[name] = {"method": "PyMOL cealign", "RMSD_angstrom": float(res["RMSD"]),
                     "n_aligned_atoms": int(res["alignment_length"])}
    except Exception as e:
        ali[name] = {"error": repr(e)[:200]}
report["superposition"] = ali
cmd.hide("everything"); cmd.show("cartoon", "cat or itevi or uvrc")
cmd.color("0xCC79A7", "cat"); cmd.color("0x1A1A1A", "itevi"); cmd.color("0xA3A3A3", "uvrc")
cmd.set("cartoon_transparency", 0.0, "cat")
cmd.orient("cat")
report["view_superposition"] = list(cmd.get_view())
cmd.png(f"{OUT}/panel_superposition.png", width=1800, height=1500, dpi=600, ray=1)
json.dump(report, open(f"{OUT}/render-report.json", "w"), indent=1)
