#!/usr/bin/env python3
"""ESMFold2 smoke test on spark-d3de (aarch64 / GB10).

ONE kernel backend per process AND one backend per Slurm job (Codex review 2026-10-16,
item 2): no in-process fallback, and no second model load in the same job - the first
attempt at that pattern hit `torch.AcceleratorError: CUDA error: out of memory` because
the previous process's device memory had not been released.

Records host and GPU memory peaks so the production job can be sized from measurement
rather than estimate (item 3). Model snapshot is pinned and loaded offline (item 5).
Does not touch ORF102.
"""
import json, os, sys, time, traceback

# --- CPU-SVD compatibility patch -------------------------------------------------
# Source      : skill `esmfold2`, "Gotcha: cusolver SVD poison + structseq constructor".
#               Upstream cause: Kabsch alignment in modeling_esmfold2_common.py calls
#               torch.linalg.svd(H32, driver="gesvd") on batched 3x3 matrices; non-finite
#               inputs corrupt the cusolver workspace so ALL later CUDA calls fail with
#               illegal memory access.
# Applies to  : CUDA tensors whose two trailing dims are both <= 4 (the batched Kabsch
#               case). Every other SVD call is passed through unchanged.
# Modification: the skill's published snippet additionally ran torch.nan_to_num() on
#               non-finite inputs. REMOVED here (Codex review 2026-10-16): substituting
#               0 / +-1e6 for NaN/Inf would let a degenerate diffusion sample continue and
#               emit coordinates. A non-finite input now raises NonFiniteSVDInput and the
#               attempt is recorded as FAILED. Only finite inputs are processed.
# --------------------------------------------------------------------------------
import torch

class NonFiniteSVDInput(RuntimeError):
    """Kabsch SVD received NaN/Inf -> the prediction attempt is void."""

_SVD_STATS = {"cpu_redirected": 0, "passthrough": 0}
_orig_svd = torch.linalg.svd

def _safe_svd(A, full_matrices=True, driver=None):
    if A.is_cuda and A.shape[-1] <= 4 and A.shape[-2] <= 4:
        Acpu = A.detach().float().cpu()
        if not torch.isfinite(Acpu).all():
            n_bad = int((~torch.isfinite(Acpu)).sum())
            raise NonFiniteSVDInput(
                f"non-finite values in batched Kabsch SVD input: {n_bad} of {Acpu.numel()} "
                f"elements, shape {tuple(Acpu.shape)} - attempt void, no coordinates emitted")
        _SVD_STATS["cpu_redirected"] += 1
        out = _orig_svd(Acpu, full_matrices=full_matrices)
        return type(out)(tuple(t.to(A.device, A.dtype) for t in out))   # C structseq: ONE tuple
    _SVD_STATS["passthrough"] += 1
    return _orig_svd(A, full_matrices=full_matrices, driver=driver)

torch.linalg.svd = _safe_svd

from esm.models.esmfold2 import ESMFold2InputBuilder, StructurePredictionInput, ProteinInput
from transformers.models.esmfold2.modeling_esmfold2 import ESMFold2Model

def as_result_list(out):
    """esm 3.3.0 ESMFold2InputBuilder.fold() returns a SINGLE MolecularComplexResult when
    num_diffusion_samples == 1 and a list otherwise (verified from the installed docstring,
    2026-10-16). Normalise to a list; never index the raw return."""
    return list(out) if isinstance(out, (list, tuple)) else [out]

def mem_snapshot(tag):
    d = {"tag": tag}
    if torch.cuda.is_available():
        d["cuda_alloc_GB"] = round(torch.cuda.memory_allocated() / 2**30, 3)
        d["cuda_reserved_GB"] = round(torch.cuda.memory_reserved() / 2**30, 3)
        d["cuda_max_alloc_GB"] = round(torch.cuda.max_memory_allocated() / 2**30, 3)
        d["cuda_max_reserved_GB"] = round(torch.cuda.max_memory_reserved() / 2**30, 3)
    try:
        import resource
        d["host_maxrss_GB"] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20, 3)
    except Exception:
        pass
    return d

BACKEND = sys.argv[1]
assert BACKEND in ("fused", "reference"), f"argv[1] must be fused|reference, got {BACKEND!r}"
REVISION = "8fc3ff471022fdce52c77030685eb775de0c00a3"   # pinned ESMFold2 snapshot
PEP = "MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQ"               # 33 aa test peptide, not ORF102
OUT = f"smoke-report-{BACKEND}.json"

rep = {"backend_under_test": BACKEND, "revision_pinned": REVISION,
       "hf_hub_offline": os.environ.get("HF_HUB_OFFLINE"),
       "pytorch_cuda_alloc_conf": os.environ.get("PYTORCH_CUDA_ALLOC_CONF"),
       "torch": torch.__version__, "torch_cuda_runtime": torch.version.cuda,
       "cuda_available": torch.cuda.is_available(),
       "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
       "mem": [], "status": "started"}
try:
    import accelerate; rep["accelerate"] = accelerate.__version__
except ImportError:
    rep["accelerate"] = None

def finish(ok, **kw):
    rep["mem"].append(mem_snapshot("final"))
    rep.update(status=("ok" if ok else "failed"), svd_stats=dict(_SVD_STATS), **kw)
    json.dump(rep, open(OUT, "w"), indent=1)
    print(json.dumps(rep, indent=1), flush=True)
    sys.exit(0 if ok else 1)

try:
    assert torch.cuda.is_available(), "CUDA not available inside the Slurm job"
    rep["mem"].append(mem_snapshot("before_load"))
    # Load weights DIRECTLY onto the device, shard by shard, instead of
    # from_pretrained(...).cuda(). Measured on this host (job e7563624): the model is
    # 6.58e9 params / 12.694 GB, and a CPU-resident copy plus the device copy does not
    # fit -- CUDA-visible free memory was 15.69 GB at job start and 3.03 GB after the CPU
    # load, because ~97 GB of the GB10 unified pool is held as page cache that the CUDA
    # driver cannot use. device_map keeps only one copy. Per-parameter dtypes are left as
    # stored (11.819 GB bfloat16 + 0.875 GB float32); no precision change is introduced.
    t0 = time.time()
    model = ESMFold2Model.from_pretrained(
        "biohub/ESMFold2", revision=REVISION, device_map={"": "cuda:0"}).eval()
    rep["load_s"] = round(time.time() - t0, 1)
    rep["load_path"] = 'from_pretrained(device_map={"": "cuda:0"})'
    rep["param_total_GB_measured"] = round(
        sum(p.numel() * p.element_size() for p in model.parameters()) / 2**30, 3)
    rep["num_plddt_bins"] = getattr(model.config, "num_plddt_bins", None)
    rep["mem"].append(mem_snapshot("after_load_to_gpu"))

    if BACKEND == "fused":
        model.set_kernel_backend("fused"); model.set_chunk_size(None)
    else:
        model.set_kernel_backend(None); model.set_chunk_size(64)

    spi = StructurePredictionInput(sequences=[ProteinInput(id="A", sequence=PEP)])
    t1 = time.time()
    out = ESMFold2InputBuilder().fold(model, spi, num_loops=2, num_sampling_steps=16,
                                      num_diffusion_samples=1, seed=0)
    rep["fold_s"] = round(time.time() - t1, 1)
    rep["mem"].append(mem_snapshot("after_fold"))

    results = as_result_list(out)
    rep["fold_return_type"] = type(out).__name__
    rep["n_results"] = len(results)
    p = results[0]
    pl = p.plddt.detach().float().cpu().numpy()
    cif = p.complex.to_mmcif()
    open(f"smoke-{BACKEND}.cif", "w").write(cif)
    # pLDDT scale is READ OFF THE INSTALLED IMPLEMENTATION, not inferred from values:
    #   modeling_esmfold2_experimental.py:220
    #     plddt_per_atom = _categorical_mean(plddt_logits, start=0.0, end=1.0)  -> native 0-1
    #   molecular_complex.py:858
    #     atom_bfactors[start:end] = self.plddt[token_idx] * 100.0              -> mmCIF 0-100
    rep.update(plddt_len=int(pl.shape[0]), seq_len=len(PEP),
               plddt_raw_min=float(pl.min()), plddt_raw_max=float(pl.max()),
               plddt_raw_mean=float(pl.mean()),
               plddt_scale_native="0-1 (modeling_esmfold2_experimental.py:220, "
                                  "_categorical_mean(plddt_logits, start=0.0, end=1.0); "
                                  "config.num_plddt_bins bins)",
               plddt_scale_in_mmcif="0-100 (molecular_complex.py:858, plddt * 100.0)",
               plddt_consistent_with_native_range=bool(float(pl.min()) >= 0.0 and float(pl.max()) <= 1.0),
               ptm=(float(p.ptm) if p.ptm is not None else None),
               pae_shape=(list(p.pae.shape) if p.pae is not None else None),
               mmcif_bytes=len(cif))
    finish(True)
except NonFiniteSVDInput as e:
    finish(False, failure_kind="non_finite_svd_input", error=str(e))
except Exception as e:
    finish(False, failure_kind=type(e).__name__, error=repr(e)[:900],
           traceback=traceback.format_exc()[-2500:])
