#!/usr/bin/env python3
"""ORF102 (vctg2997-cat_1_102, vOTU0052, 211 aa) monomer structure prediction, ESMFold2.

Established on this host by smoke test job 98406c8e:
  * kernel backend = reference. `fused` is UNAVAILABLE here: Triton JIT needs the CUDA
    driver header cuda.h, absent from this env (job 4c30a158, slurm-1267). Deterministic.
  * weights are loaded directly to the device via device_map; the CPU-copy path OOMs
    (job 6d30dc03) because ~97 GB of the GB10 unified pool is page cache the CUDA driver
    cannot use, leaving ~15.7 GB CUDA-visible free against a 12.694 GB model.
  * fold() returns a single MolecularComplexResult when num_diffusion_samples == 1 and a
    list otherwise -- normalised here, never indexed raw.

Single-sequence mode: NO MSA, NO templates. Snapshot pinned, loaded offline.
pLDDT is emitted on the implementation's native 0-1 scale; see PLDDT_SCALE below.
No in-process recovery from CUDA errors: any failure ends the process non-zero with the
full traceback recorded.

Usage: predict_orf102.py --samples N --seed S [--tag LABEL]
"""
import argparse, hashlib, json, os, sys, time, traceback, resource
import numpy as np
# --- CPU-SVD compatibility patch -------------------------------------------------
# Source      : skill `esmfold2`, "Gotcha: cusolver SVD poison + structseq constructor".
#               Upstream cause: Kabsch alignment in modeling_esmfold2_common.py calls
#               torch.linalg.svd(H32, driver="gesvd") on batched 3x3 matrices; non-finite
#               inputs corrupt the cusolver workspace so ALL later CUDA calls fail with
#               illegal memory access.
# Applies to  : CUDA tensors whose two trailing dims are both <= 4 (the batched Kabsch
#               case). Every other SVD call is passed through unchanged.
# Modification: the skill's published snippet additionally ran torch.nan_to_num() on
#               non-finite inputs. REMOVED here (Codex review 2026-10-16): substituting
#               0 / +-1e6 for NaN/Inf would let a degenerate diffusion sample continue and
#               emit coordinates. A non-finite input now raises NonFiniteSVDInput and the
#               attempt is recorded as FAILED. Only finite inputs are processed.
# --------------------------------------------------------------------------------
import torch

class NonFiniteSVDInput(RuntimeError):
    """Kabsch SVD received NaN/Inf -> the prediction attempt is void."""

_SVD_STATS = {"cpu_redirected": 0, "passthrough": 0}
_orig_svd = torch.linalg.svd

def _safe_svd(A, full_matrices=True, driver=None):
    if A.is_cuda and A.shape[-1] <= 4 and A.shape[-2] <= 4:
        Acpu = A.detach().float().cpu()
        if not torch.isfinite(Acpu).all():
            n_bad = int((~torch.isfinite(Acpu)).sum())
            raise NonFiniteSVDInput(
                f"non-finite values in batched Kabsch SVD input: {n_bad} of {Acpu.numel()} "
                f"elements, shape {tuple(Acpu.shape)} - attempt void, no coordinates emitted")
        _SVD_STATS["cpu_redirected"] += 1
        out = _orig_svd(Acpu, full_matrices=full_matrices)
        return type(out)(tuple(t.to(A.device, A.dtype) for t in out))   # C structseq: ONE tuple
    _SVD_STATS["passthrough"] += 1
    return _orig_svd(A, full_matrices=full_matrices, driver=driver)

torch.linalg.svd = _safe_svd

from esm.models.esmfold2 import ESMFold2InputBuilder, StructurePredictionInput, ProteinInput
from transformers.models.esmfold2.modeling_esmfold2 import ESMFold2Model

REVISION = "8fc3ff471022fdce52c77030685eb775de0c00a3"
SEQ_SHA256 = "e4cc7f1689611b6cedd073b88ea9558d4e796837f4ac4db7ed14cf7b2436eda0"
PLDDT_SCALE = {
    "native": "0-1; modeling_esmfold2_experimental.py:220 -> "
              "plddt_per_atom = _categorical_mean(plddt_logits, start=0.0, end=1.0)",
    "in_mmcif_bfactor": "0-100; molecular_complex.py:858 -> atom_bfactors = plddt * 100.0",
    "conversion_rule": "mmcif_bfactor = native_plddt * 100; files here store NATIVE 0-1",
}
# Partition fixed in REVISION-NOTES.md (primary = Pfam alignment boundaries), 1-based inclusive
REGIONS = {"N_flank": (1, 2), "catalytic_GIY_YIG": (3, 87),
           "inter_domain_unannotated": (88, 152), "binding_NUMOD_like": (153, 184),
           "C_flank": (185, 211)}
AA3TO1 = {"ALA":"A","ARG":"R","ASN":"N","ASP":"D","CYS":"C","GLN":"Q","GLU":"E","GLY":"G",
          "HIS":"H","ILE":"I","LEU":"L","LYS":"K","MET":"M","PHE":"F","PRO":"P","SER":"S",
          "THR":"T","TRP":"W","TYR":"Y","VAL":"V"}

ap = argparse.ArgumentParser()
ap.add_argument("--samples", type=int, required=True)
ap.add_argument("--seed", type=int, required=True)
ap.add_argument("--num-loops", type=int, default=10)
ap.add_argument("--num-sampling-steps", type=int, default=68)
ap.add_argument("--tag", default="")
a = ap.parse_args()
TAG = a.tag or f"s{a.samples}_seed{a.seed}"

def mem(tag):
    d = {"tag": tag,
         "host_maxrss_GB": round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20, 3)}
    if torch.cuda.is_available():
        free, total = torch.cuda.mem_get_info()
        d.update(cuda_free_GB=round(free / 2**30, 3), cuda_total_GB=round(total / 2**30, 3),
                 cuda_alloc_GB=round(torch.cuda.memory_allocated() / 2**30, 3),
                 cuda_max_alloc_GB=round(torch.cuda.max_memory_allocated() / 2**30, 3),
                 cuda_max_reserved_GB=round(torch.cuda.max_memory_reserved() / 2**30, 3))
    run["mem"].append(d); print(json.dumps(d), flush=True); return d

def as_result_list(out):
    return list(out) if isinstance(out, (list, tuple)) else [out]

SEQ = "".join(l.strip() for l in open("ORF102.fasta") if not l.startswith(">"))
run = {"tag": TAG, "mem": [], "status": "started",
       "parameterisation": (f"public reference parameters; num_loops={a.num_loops}, "
                            f"num_sampling_steps={a.num_sampling_steps}, "
                            f"num_diffusion_samples={a.samples}, seed={a.seed}. "
                            "NOT a reproduction of the published FoldBench evaluation "
                            "(which uses 25 seeds x 5 diffusion samples)."),
       "msa": "none (single-sequence mode)", "templates": "none",
       "model_repo": "biohub/ESMFold2", "revision_pinned": REVISION,
       "kernel_backend": "reference (fused unavailable: cuda.h absent for Triton JIT)",
       "chunk_size": 64, "plddt_scale": PLDDT_SCALE,
       "hf_hub_offline": os.environ.get("HF_HUB_OFFLINE"),
       "torch": torch.__version__, "torch_cuda_runtime": torch.version.cuda,
       "seq_len": len(SEQ), "seq_sha256": hashlib.sha256(SEQ.encode()).hexdigest()}

def finish(ok, **kw):
    mem("final")
    run.update(status=("ok" if ok else "failed"), svd_stats=dict(_SVD_STATS), **kw)
    json.dump(run, open(f"orf102-run-report-{TAG}.json", "w"), indent=1)
    print(json.dumps({k: v for k, v in run.items() if k not in ("mem", "per_sample")}, indent=1),
          flush=True)
    sys.exit(0 if ok else 1)

try:
    assert len(SEQ) == 211, f"expected 211 aa, got {len(SEQ)}"
    assert run["seq_sha256"] == SEQ_SHA256, "input sequence SHA256 mismatch"
    assert torch.cuda.is_available(), "CUDA not available inside the Slurm job"
    mem("before_load")

    t0 = time.time()
    model = ESMFold2Model.from_pretrained(
        "biohub/ESMFold2", revision=REVISION, device_map={"": "cuda:0"}).eval()
    run["load_s"] = round(time.time() - t0, 1)
    run["param_total_GB"] = round(
        sum(p.numel() * p.element_size() for p in model.parameters()) / 2**30, 3)
    model.set_kernel_backend(None); model.set_chunk_size(64)
    after_load = mem("after_load_to_gpu")

    spi = StructurePredictionInput(sequences=[ProteinInput(id="A", sequence=SEQ)])
    t1 = time.time()
    out = ESMFold2InputBuilder().fold(model, spi, num_loops=a.num_loops,
                                      num_sampling_steps=a.num_sampling_steps,
                                      num_diffusion_samples=a.samples, seed=a.seed)
    run["fold_s"] = round(time.time() - t1, 1)
    after_fold = mem("after_fold")
    run["fold_return_type"] = type(out).__name__
    results = as_result_list(out)
    run["n_results"] = len(results)
    run["activation_peak_GB_above_weights"] = round(
        after_fold["cuda_max_alloc_GB"] - run["param_total_GB"], 3)

    rows = []
    for i, p in enumerate(results):
        pl = p.plddt.detach().float().cpu().numpy().astype(float)
        assert pl.shape[0] == len(SEQ), f"sample {i}: pLDDT length {pl.shape[0]} != {len(SEQ)}"
        name = f"orf102_{TAG}_sample{i}"
        np.savetxt(f"plddt_{name}.txt", pl, fmt="%.6f")
        if p.pae is not None:
            np.save(f"pae_{name}.npy", p.pae.detach().float().cpu().numpy())
        cif = p.complex.to_mmcif()
        open(f"{name}.cif", "w").write(cif)
        rec = {"sample": i, "file": f"{name}.cif",
               "plddt_mean_native": float(pl.mean()), "plddt_min_native": float(pl.min()),
               "plddt_max_native": float(pl.max()),
               "plddt_within_0_1": bool(pl.min() >= 0.0 and pl.max() <= 1.0),
               "ptm": (float(p.ptm) if p.ptm is not None else None),
               "iptm": (float(p.iptm) if p.iptm is not None else None),
               "pae_shape": (list(p.pae.shape) if p.pae is not None else None)}
        for rn, (s_, e_) in REGIONS.items():
            rec[f"plddt_mean__{rn}"] = float(pl[s_ - 1:e_].mean())
        # read the sequence back out of the coordinates (not from the input)
        try:
            import biotite.structure.io.pdbx as pdbx, io
            f = pdbx.CIFFile.read(io.StringIO(cif))
            arr = pdbx.get_structure(f, model=1)
            ca = arr[(arr.atom_name == "CA")]
            rec["n_CA"] = int(ca.array_length())
            rec["chains_in_coords"] = sorted(set(ca.chain_id.tolist()))
            seq_back = "".join(AA3TO1.get(r, "X") for r in ca.res_name.tolist())
            rec["seq_from_coords_matches_input"] = bool(seq_back == SEQ)
            rec["seq_from_coords_len"] = len(seq_back)
            res_ids = ca.res_id.tolist()
            rec["res_id_first_last"] = [int(res_ids[0]), int(res_ids[-1])]
            rec["res_id_contiguous"] = bool(res_ids == list(range(res_ids[0], res_ids[0] + len(res_ids))))
        except Exception as e:
            rec["coord_readback_error"] = repr(e)[:300]
        rows.append(rec)

    run["per_sample"] = rows
    best = max(range(len(rows)), key=lambda i: rows[i]["plddt_mean_native"])
    run["selected_sample"] = best
    run["selection_rule"] = "highest mean pLDDT among diffusion samples (monomer criterion)"
    sha = {}
    for r_ in rows:
        sha[r_["file"]] = hashlib.sha256(open(r_["file"], "rb").read()).hexdigest()
    run["output_sha256"] = sha
    finish(True)
except NonFiniteSVDInput as e:
    finish(False, failure_kind="non_finite_svd_input", error=str(e))
except Exception as e:
    finish(False, failure_kind=type(e).__name__, error=repr(e)[:900],
           traceback=traceback.format_exc()[-2500:])
