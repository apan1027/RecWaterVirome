#!/usr/bin/env python3
"""GB10 memory diagnostic for ESMFold2 — measurement only, no folding.

Answers, with numbers rather than assumption:
  1. how much memory the CUDA allocator actually sees on GB10 (torch.cuda.mem_get_info)
  2. what the job's cgroup limit and current usage are
  3. how large the ESMFold2 parameter set is, and in what dtype, on CPU
  4. whether moving it to the device succeeds, and at what point it fails
Written because the reference-backend smoke test (job 6d30dc03) raised
`torch.AcceleratorError: CUDA error: out of memory` inside .cuda() at host RSS 16.65 GB
with cuda_alloc 0 GB under --mem=96G.
"""
import json, os, sys, time, traceback, resource
import torch
from transformers.models.esmfold2.modeling_esmfold2 import ESMFold2Model

REVISION = "8fc3ff471022fdce52c77030685eb775de0c00a3"
rep = {"revision_pinned": REVISION, "torch": torch.__version__,
       "pytorch_cuda_alloc_conf": os.environ.get("PYTORCH_CUDA_ALLOC_CONF"),
       "slurm_mem_declared": os.environ.get("SLURM_MEM_PER_NODE"), "steps": []}

def rss_gb():
    return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 2**20, 3)

def cuda_info(tag):
    d = {"tag": tag, "host_maxrss_GB": rss_gb()}
    if torch.cuda.is_available():
        free, total = torch.cuda.mem_get_info()
        d["cuda_mem_get_info_free_GB"] = round(free / 2**30, 3)
        d["cuda_mem_get_info_total_GB"] = round(total / 2**30, 3)
        d["cuda_alloc_GB"] = round(torch.cuda.memory_allocated() / 2**30, 3)
        d["cuda_reserved_GB"] = round(torch.cuda.memory_reserved() / 2**30, 3)
    rep["steps"].append(d)
    print(json.dumps(d), flush=True)
    return d

def read_cgroup():
    out = {}
    for name in ("memory.max", "memory.current", "memory.high"):
        for base in ("/sys/fs/cgroup", "/sys/fs/cgroup/memory"):
            p = os.path.join(base, name)
            if os.path.exists(p):
                try: out[name] = open(p).read().strip()
                except Exception as e: out[name] = f"unreadable: {e}"
                break
    try:
        out["self_cgroup"] = open("/proc/self/cgroup").read().strip()[:300]
    except Exception:
        pass
    return out

try:
    rep["cgroup"] = read_cgroup()
    print(json.dumps(rep["cgroup"]), flush=True)
    cuda_info("start")

    t0 = time.time()
    model = ESMFold2Model.from_pretrained("biohub/ESMFold2", revision=REVISION)   # CPU only
    rep["load_cpu_s"] = round(time.time() - t0, 1)
    cuda_info("after_cpu_load")

    by_dtype = {}
    total_bytes = 0
    for p in model.parameters():
        k = str(p.dtype)
        by_dtype[k] = by_dtype.get(k, 0) + p.numel() * p.element_size()
        total_bytes += p.numel() * p.element_size()
    for b in model.buffers():
        k = str(b.dtype) + " (buffer)"
        by_dtype[k] = by_dtype.get(k, 0) + b.numel() * b.element_size()
        total_bytes += b.numel() * b.element_size()
    rep["param_bytes_by_dtype_GB"] = {k: round(v / 2**30, 3) for k, v in by_dtype.items()}
    rep["param_total_GB"] = round(total_bytes / 2**30, 3)
    rep["n_params"] = sum(p.numel() for p in model.parameters())
    print(json.dumps({"param_total_GB": rep["param_total_GB"],
                      "by_dtype": rep["param_bytes_by_dtype_GB"],
                      "n_params": rep["n_params"]}), indent=1, flush=True)

    try:
        model = model.cuda()
        cuda_info("after_to_cuda_fp_native")
        rep["to_cuda_native"] = "ok"
    except Exception as e:
        rep["to_cuda_native"] = f"FAILED: {type(e).__name__}: {repr(e)[:300]}"
        cuda_info("after_to_cuda_failure")
    rep["status"] = "ok"
except Exception as e:
    rep["status"] = "failed"
    rep["failure_kind"] = type(e).__name__
    rep["error"] = repr(e)[:900]
    rep["traceback"] = traceback.format_exc()[-2000:]

json.dump(rep, open("mem-diagnostic.json", "w"), indent=1)
print(json.dumps({k: v for k, v in rep.items() if k != "steps"}, indent=1), flush=True)
